#!/bin/bash
# Copyright 2014-2016 Rocket Software, Inc. All rights reserved.
source_enc=ISO8859-15
target_enc=$(locale charmap)
start_wd=$(pwd)
cd $1/bin
for file in *.sh *.bat
do
  cp $file $file.bak ; iconv -f $source_enc -t $target_enc -T $file.bak >$file ; chmod 777 $file
done
for file in *.conf *.txt
do
  cp $file $file.bak ; iconv -f $source_enc -t $target_enc -T $file.bak >$file
done
cd $start_wd
