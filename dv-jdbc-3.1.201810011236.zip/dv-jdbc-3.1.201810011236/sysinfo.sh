#!/bin/bash
# Copyright 2014-2016 Rocket Software, Inc. All rights reserved.
java -cp *:. com.rs.dv.util.PrintStreamEnvironmentReporter $@
